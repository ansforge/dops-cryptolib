Activation et d�sactivation des traces compl�tes de la Cryptolib CPS sous Windows au niveau Local Machine

Avant utilisation : *.txt � renommer en *.reg

Sur les plateformes 32 bits, utiliser activation_traces_all_HKLM_x32.reg et desactivation_traces_all_HKLM_x32.reg

Sur les plateformes 64 bits, utiliser activation_traces_all_HKLM_x64.reg et desactivation_traces_all_HKLM_x64.reg
