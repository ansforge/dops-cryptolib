/*
* sys_config.c : System configuration dependent functions
*
* Copyright (C) 2010-2016, ASIP Santé
*
* This library is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 2.1 of the License, or (at your option) any later version.
*
* This library is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public
* License along with this library; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#define CPS_FOLDER_CONF  0x01
#define CPS_FOLDER_LOG   0x02
#define CPS_FOLDER_CACHE 0x03



#ifdef _WIN32

#include <windows.h>
#include <shlobj.h>
#include <direct.h>
#include <stdio.h>

typedef HRESULT(__stdcall * tSHGetFolderPath)(HWND hwndOwner, INT nFolder, HANDLE hToken, DWORD dwFlags, LPTSTR pszPath);

#define STR_CPS_FOLDER_CONF  "\\coffre"
#define STR_CPS_FOLDER_LOG   "\\log"
#define STR_CPS_FOLDER_CACHE "\\cache"


VOID sys_GetPath(LPSTR strConfPath, size_t szSize, BYTE type)
{
  CHAR szPath[MAX_PATH] = { 0 };
  CHAR szFindPath[MAX_PATH] = { 0 };
  PCHAR strPathType = NULL;
  BOOL bAppDataExist = FALSE;
  HINSTANCE pShell32Dll = NULL;
  WIN32_FIND_DATA FindData;

  pShell32Dll = LoadLibrary((LPCSTR)"Shell32.dll");
  if (pShell32Dll != NULL) {
    tSHGetFolderPath pSHGetFolderPath;
    pSHGetFolderPath = (tSHGetFolderPath)GetProcAddress(pShell32Dll, "SHGetFolderPathA");
    if (pSHGetFolderPath != NULL) {
      if (((tSHGetFolderPath)pSHGetFolderPath)(NULL, CSIDL_COMMON_APPDATA, NULL, 0, szPath) != S_FALSE) {
        if (szPath[0] != 0) {
          strncpy(szFindPath, szPath, min(szSize, MAX_PATH));
          bAppDataExist = TRUE;
        }
      }
    }
    FreeLibrary(pShell32Dll);
  }

  if (!bAppDataExist) {
    GetEnvironmentVariable("ALLUSERSPROFILE", szPath, sizeof(szPath));
    if (szPath[0] != 0) {
      bAppDataExist = TRUE;
    }
  }

  if (type == CPS_FOLDER_CONF) { strPathType = STR_CPS_FOLDER_CONF; }
  else if (type == CPS_FOLDER_LOG) { strPathType = STR_CPS_FOLDER_LOG; }
  else if (type == CPS_FOLDER_CACHE) { strPathType = STR_CPS_FOLDER_CACHE; }


  if (bAppDataExist && strPathType != NULL) {
    HANDLE hFind = NULL;

    /* Verifiy the presence of application directory */
    sprintf(szFindPath, "%s\\santesocial\\cps%s\\*", szPath, strPathType);
    hFind = FindFirstFile(szFindPath, &FindData);

    if (hFind == INVALID_HANDLE_VALUE) {
      sprintf(szFindPath, "%s\\santesocial", szPath);
      if (!CreateDirectory(szFindPath, NULL) && (GetLastError() != ERROR_ALREADY_EXISTS)) { return; }
      strcat(szFindPath, "\\cps");
      if (!CreateDirectory(szFindPath, NULL) && (GetLastError() != ERROR_ALREADY_EXISTS)) { return; }
      strcat(szFindPath, strPathType);
      if (!CreateDirectory(szFindPath, NULL) && (GetLastError() != ERROR_ALREADY_EXISTS)) { return; }
    }
    else {
      FindClose(hFind);
    }
    sprintf(szFindPath, "%s\\santesocial\\cps%s\\", szPath, strPathType);
    if ((strConfPath != NULL) && (strlen(szFindPath) <= szSize)) {
      strcpy(strConfPath, szFindPath);
    }
  }
}

DWORD sys_GetDWRegParam(HKEY hKey, LPCSTR subKey, LPCSTR key, LPDWORD pdwValue)
{
  DWORD rc;
  HKEY hkeyRes;
  DWORD dwRegValue = 0L;
  DWORD dwRegValueLen = sizeof(DWORD);
  DWORD dwRegType = 0L;

  if ((hKey == NULL) || (subKey == NULL) || (key == NULL) || (pdwValue == NULL)) {
    return ERROR_INVALID_PARAMETER;
  }

  rc = RegOpenKeyExA(hKey, subKey, 0, KEY_QUERY_VALUE, &hkeyRes);
  if (rc == ERROR_SUCCESS) {
    rc = RegQueryValueEx(hkeyRes, key, 0, &dwRegType, (LPBYTE)&dwRegValue, &dwRegValueLen);
    if ((rc == ERROR_SUCCESS)) {
      *pdwValue = (INT)dwRegValue;
    }
    RegCloseKey(hkeyRes);
  }
  return rc;
}
#else

#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>
#include "sys_config.h"

#ifdef __APPLE__
#define STR_CPS_FOLDER_CONF        "/Library/Preferences/santesocial/CPS"
#define STR_CPS_FOLDER_LOG         "/Library/Logs/santesocial/CPS"
#define STR_CPS_FOLDER_LOG_SANDBOX "Logs/PKCS11"
#define STR_CPS_FOLDER_CACHE       "/Library/Caches/santesocial/CPS"
#ifdef _MACOS_PKCS11_
extern int g_sandboxed;
#endif
#endif

#ifdef UNIX_LUX
#define STR_CPS_FOLDER_CONF   "/etc/opt/santesocial/CPS"
#define STR_CPS_FOLDER_LOG    "/var/opt/santesocial/CPS/log"
#define STR_CPS_FOLDER_CACHE  "/etc/opt/santesocial/CPS/cache"
#endif


static INT sys_do_mkdir(LPCSTR path, mode_t mode)
{
  struct stat  st;
  INT          status = 0;
  mode_t       save_umask = 0;

  if (stat(path, &st) != 0)
  {
    save_umask = umask(0);
    /* Directory does not exist */
    if (mkdir(path, mode) != 0) {
      status = -1;
    }
    umask(save_umask);
  }
  else if (!S_ISDIR(st.st_mode))
  {
    errno = ENOTDIR;
    status = -1;
  }

  return(status);
}

INT mkpath(LPCSTR path, mode_t mode)
{
  LPSTR  pp = NULL;
  LPSTR  sp = NULL;
  INT    status = 0;
  LPSTR  copypath = strdup(path);

  pp = copypath;
  while (status == 0 && (sp = strchr(pp, '/')) != 0)
  {
    if (sp != pp)
    {
      /* Neither root nor double slash in path */
      *sp = '\0';
      status = sys_do_mkdir(copypath, mode);
      *sp = '/';
    }
    pp = sp + 1;
  }
  if (status == 0) {
    status = sys_do_mkdir(path, mode);
  }
  free(copypath);
  return (status);
}

VOID sys_GetPath(LPSTR strConfPath, size_t szSize, BYTE type)
{
  CHAR needPath[256] = "";

#if defined(__APPLE__) && defined(_MACOS_PKCS11_)
  if (type == CPS_FOLDER_LOG){
    if(g_sandboxed){ strcpy(needPath, getenv("TMPDIR") );}
    else{ strcpy(needPath, getenv("HOME") ); }
  }else {
    if (g_sandboxed) {
      strcpy(needPath,".");
    }
  }
#endif
  if (type == CPS_FOLDER_CONF) { strcat(needPath, STR_CPS_FOLDER_CONF); }
#if defined(__APPLE__) && defined(_MACOS_PKCS11_)
  else if (type == CPS_FOLDER_LOG && g_sandboxed) { strcat(needPath, STR_CPS_FOLDER_LOG_SANDBOX); }
  else if (type == CPS_FOLDER_LOG && !g_sandboxed) { strcat(needPath, STR_CPS_FOLDER_LOG); }
#else
  else if (type == CPS_FOLDER_LOG) { strcat(needPath, STR_CPS_FOLDER_LOG); }
#endif
  else if (type == CPS_FOLDER_CACHE) { strcat(needPath, STR_CPS_FOLDER_CACHE); }

  mkpath(needPath, 0777);
  if( strConfPath != NULL ){
    strcpy(strConfPath, needPath);
    strcat(strConfPath, "/");
  }
  return;
}



#endif // _WIN32



VOID sys_GetLogPath(LPSTR strConfPath, size_t szSize) {
  sys_GetPath(strConfPath, szSize, CPS_FOLDER_LOG);
}

VOID sys_GetCachePath(LPSTR strConfPath, size_t szSize) {
  sys_GetPath(strConfPath, szSize, CPS_FOLDER_CACHE);
}

VOID sys_GetConfPath(LPSTR strConfPath, size_t szSize) {
  sys_GetPath(strConfPath, szSize, CPS_FOLDER_CONF);
}
