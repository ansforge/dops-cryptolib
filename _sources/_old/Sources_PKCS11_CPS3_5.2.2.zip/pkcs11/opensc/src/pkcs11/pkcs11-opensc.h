#ifndef PKCS11_OPENSC_H
#define PKCS11_OPENSC_H

/* OpenSC specific extensions */

#endif
