#include "pkcs11.h"

//CK_RV launchThreads(CK_ULONG nbThread, CK_CHAR_PTR pin);
unsigned char testAll(unsigned char * pin);

