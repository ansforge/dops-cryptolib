// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__BE43EE1C_22E8_462B_BF10_7B254CC58FB0__INCLUDED_)
#define AFX_STDAFX_H__BE43EE1C_22E8_462B_BF10_7B254CC58FB0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


// TODO: reference additional headers your program requires here

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__BE43EE1C_22E8_462B_BF10_7B254CC58FB0__INCLUDED_)
