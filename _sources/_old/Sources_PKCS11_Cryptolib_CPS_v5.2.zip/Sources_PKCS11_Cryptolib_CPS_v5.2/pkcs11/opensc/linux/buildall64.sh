bash build64.sh d clean
bash build64.sh r clean

