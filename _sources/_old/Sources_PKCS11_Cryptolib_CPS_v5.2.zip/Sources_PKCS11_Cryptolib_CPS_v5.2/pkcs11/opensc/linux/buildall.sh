bash build.sh d clean
bash build.sh r clean

