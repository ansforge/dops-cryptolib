/*
 * pkcs15-cert.c: PKCS #15 certificate functions
 *
 * Copyright (C) 2001, 2002  Juha Yrjölä <juha.yrjola@iki.fi>
 * Copyright (C) 2010-2016, ASIP Santé
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "internal.h"
#include "pkcs15.h"
#include "asn1.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <sys/stat.h>
#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif
#include <assert.h>

/* BPER (@@20150323-00001232 - Patcher l'octet Unused bits - debut */
static int parse_x509_cert(sc_context_t *ctx, const u8 *buf, size_t buflen, struct sc_pkcs15_cert *cert, size_t * offset_patch)
{
  int r;
    u8 * sigValue;
    size_t sigLen;

  struct sc_algorithm_id pk_alg, sig_alg;
  sc_pkcs15_der_t pk = { NULL, 0 };
  struct sc_asn1_entry asn1_version[] = {
    { "version", SC_ASN1_INTEGER, SC_ASN1_TAG_INTEGER, 0, &cert->version, NULL },
    { NULL, 0, 0, 0, NULL, NULL }
  };
  struct sc_asn1_entry asn1_pkinfo[] = {
    { "algorithm",    SC_ASN1_ALGORITHM_ID,  SC_ASN1_TAG_SEQUENCE | SC_ASN1_CONS, 0, &pk_alg, NULL },
    { "subjectPublicKey",  SC_ASN1_BIT_STRING_NI, SC_ASN1_TAG_BIT_STRING, SC_ASN1_ALLOC, &pk.value, &pk.len },
    { NULL, 0, 0, 0, NULL, NULL }
  };
  struct sc_asn1_entry asn1_x509v3[] = {
    { "certificatePolicies",  SC_ASN1_OCTET_STRING, SC_ASN1_SEQUENCE | SC_ASN1_CONS, SC_ASN1_OPTIONAL, NULL, NULL },
    { "subjectKeyIdentifier",  SC_ASN1_OCTET_STRING, SC_ASN1_SEQUENCE | SC_ASN1_CONS, SC_ASN1_OPTIONAL, NULL, NULL },
    { "crlDistributionPoints",  SC_ASN1_OCTET_STRING, SC_ASN1_SEQUENCE | SC_ASN1_CONS, SC_ASN1_OPTIONAL | SC_ASN1_ALLOC, &cert->crl, &cert->crl_len },
    { "authorityKeyIdentifier",  SC_ASN1_OCTET_STRING, SC_ASN1_SEQUENCE | SC_ASN1_CONS, SC_ASN1_OPTIONAL, NULL, NULL },
    { "keyUsage",      SC_ASN1_BOOLEAN, SC_ASN1_SEQUENCE | SC_ASN1_CONS, SC_ASN1_OPTIONAL, NULL, NULL },
    { NULL, 0, 0, 0, NULL, NULL }
  };
  struct sc_asn1_entry asn1_extensions[] = {
    { "x509v3",    SC_ASN1_STRUCT,    SC_ASN1_TAG_SEQUENCE | SC_ASN1_CONS, SC_ASN1_OPTIONAL, asn1_x509v3, NULL },
    { NULL, 0, 0, 0, NULL, NULL }
  };
  struct sc_asn1_entry asn1_tbscert[] = {
    { "version",    SC_ASN1_STRUCT,    SC_ASN1_CTX | 0 | SC_ASN1_CONS, SC_ASN1_OPTIONAL, asn1_version, NULL },
    { "serialNumber",  SC_ASN1_OCTET_STRING, SC_ASN1_TAG_INTEGER, SC_ASN1_ALLOC, &cert->serial, &cert->serial_len },
    { "signature",    SC_ASN1_STRUCT,    SC_ASN1_TAG_SEQUENCE | SC_ASN1_CONS, 0, NULL, NULL },
    { "issuer",    SC_ASN1_OCTET_STRING, SC_ASN1_TAG_SEQUENCE | SC_ASN1_CONS, SC_ASN1_ALLOC, &cert->issuer, &cert->issuer_len },
    { "validity",    SC_ASN1_STRUCT,    SC_ASN1_TAG_SEQUENCE | SC_ASN1_CONS, 0, NULL, NULL },
    { "subject",    SC_ASN1_OCTET_STRING, SC_ASN1_TAG_SEQUENCE | SC_ASN1_CONS, SC_ASN1_ALLOC, &cert->subject, &cert->subject_len },
    { "subjectPublicKeyInfo",SC_ASN1_STRUCT,   SC_ASN1_TAG_SEQUENCE | SC_ASN1_CONS, 0, asn1_pkinfo, NULL },
    { "extensions",    SC_ASN1_STRUCT,    SC_ASN1_CTX | 3 | SC_ASN1_CONS, SC_ASN1_OPTIONAL, asn1_extensions, NULL },
    { NULL, 0, 0, 0, NULL, NULL }
  };
  struct sc_asn1_entry asn1_cert[] = {
    { "tbsCertificate",  SC_ASN1_STRUCT,    SC_ASN1_TAG_SEQUENCE | SC_ASN1_CONS, 0, asn1_tbscert, NULL },
    { "signatureAlgorithm",  SC_ASN1_ALGORITHM_ID, SC_ASN1_TAG_SEQUENCE | SC_ASN1_CONS, 0, &sig_alg, NULL },
    { "signatureValue",  SC_ASN1_BIT_STRING, SC_ASN1_TAG_BIT_STRING, SC_ASN1_ALLOC, &sigValue, &sigLen },
    { NULL, 0, 0, 0, NULL, NULL }
  };
  const u8 *obj;
  size_t objlen;
  
  memset(cert, 0, sizeof(*cert));
  obj = sc_asn1_verify_tag(ctx, buf, buflen, SC_ASN1_TAG_SEQUENCE | SC_ASN1_CONS,
         &objlen);
  if (obj == NULL) {
    sc_error(ctx, "X.509 certificate not found\n");
    return SC_ERROR_INVALID_ASN1_OBJECT;
  }
  cert->data_len = objlen + (obj - buf);
  r = sc_asn1_decode(ctx, asn1_cert, obj, objlen, NULL, NULL);
  SC_TEST_RET(ctx, r, "ASN.1 parsing of certificate failed");

    *offset_patch = 0;
    if (!r) {
        if ((sigLen % 8) != 0){
            int m = 8 - (sigLen % 8);
            sigLen += m;
            *offset_patch = (sigLen/8) +1 ;
        }
    }
    if(sigValue != NULL) {free (sigValue); sigValue = 0;}
    
  cert->version++;

  cert->key.algorithm = pk_alg.algorithm;
  pk.len >>= 3;  /* convert number of bits to bytes */
  cert->key.data = pk;

  r = sc_pkcs15_decode_pubkey(ctx, &cert->key, pk.value, pk.len);
  if (r < 0)
    free(pk.value);
  sc_asn1_clear_algorithm_id(&pk_alg);
  sc_asn1_clear_algorithm_id(&sig_alg);

  return r;
}
/* BPER (@@20150323-00001232 - Patcher l'octet Unused bits - Fin */

/* BPER (@@20150323-00001232 - Patcher l'octet Unused bits - Debut */
int sc_pkcs15_read_certificate(struct sc_pkcs15_card *p15card,
             const struct sc_pkcs15_cert_info *info,
             struct sc_pkcs15_cert **cert_out)
{
  int r;
  struct sc_pkcs15_cert *cert;
  u8 *data = NULL;
   size_t len, unsued_bits_offset;
  
  assert(p15card != NULL && info != NULL && cert_out != NULL);
  SC_FUNC_CALLED(p15card->card->ctx, 1);

  if (info->path.len) {
        /* BPER (@@20150216-1226) - Paramètre supplémentaire spécifiant que l'on ne veut que la taille */
        r = sc_pkcs15_read_file(p15card, &info->path, &data, &len, NULL, info->size_only);
        /* BPER (@@20150216-1226) - Paramètre supplémentaire spécifiant que l'on ne veut que la taille - Fin */
    if (r)
      return r;
  } else {
    sc_pkcs15_der_t copy;

    sc_der_copy(&copy, &info->value);
    data = copy.value;
    len = copy.len;
  }

  cert = (struct sc_pkcs15_cert *) malloc(sizeof(struct sc_pkcs15_cert));
  if (cert == NULL) {
    free(data);
    return SC_ERROR_OUT_OF_MEMORY;
  }
  memset(cert, 0, sizeof(struct sc_pkcs15_cert));
   if (parse_x509_cert(p15card->card->ctx, data, len, cert, &unsued_bits_offset)) {
    free(data);
    free(cert);
    return SC_ERROR_INVALID_ASN1_OBJECT;
  }

   if (unsued_bits_offset > 0) { data[len-unsued_bits_offset] = 0; }
   

  cert->data = data;
  *cert_out = cert;
  return 0;
}
/* BPER (@@20150323-00001232 - Patcher l'octet Unused bits - Fin */

static const struct sc_asn1_entry c_asn1_cred_ident[] = {
  { "idType",  SC_ASN1_INTEGER,      SC_ASN1_TAG_INTEGER, 0, NULL, NULL },
  { "idValue",  SC_ASN1_OCTET_STRING, SC_ASN1_TAG_OCTET_STRING, 0, NULL, NULL },
  { NULL, 0, 0, 0, NULL, NULL }
};
static const struct sc_asn1_entry c_asn1_com_cert_attr[] = {
  { "iD",         SC_ASN1_PKCS15_ID, SC_ASN1_TAG_OCTET_STRING, 0, NULL, NULL },
  { "authority",  SC_ASN1_BOOLEAN,   SC_ASN1_TAG_BOOLEAN, SC_ASN1_OPTIONAL, NULL, NULL },
  { "identifier", SC_ASN1_STRUCT,    SC_ASN1_TAG_SEQUENCE | SC_ASN1_CONS, SC_ASN1_OPTIONAL, NULL, NULL },
  /* FIXME: Add rest of the optional fields */
  { NULL, 0, 0, 0, NULL, NULL }
};
static const struct sc_asn1_entry c_asn1_x509_cert_value_choice[] = {
  { "path",  SC_ASN1_PATH,     SC_ASN1_TAG_SEQUENCE | SC_ASN1_CONS, SC_ASN1_OPTIONAL, NULL, NULL },
  { "direct",  SC_ASN1_OCTET_STRING, SC_ASN1_CTX | 0 | SC_ASN1_CONS, SC_ASN1_OPTIONAL | SC_ASN1_ALLOC, NULL, NULL },
  { NULL, 0, 0, 0, NULL, NULL }
};
static const struct sc_asn1_entry c_asn1_x509_cert_attr[] = {
  { "value",  SC_ASN1_CHOICE, 0, 0, NULL, NULL },
  { NULL, 0, 0, 0, NULL, NULL }
};
static const struct sc_asn1_entry c_asn1_type_cert_attr[] = {
  { "x509CertificateAttributes", SC_ASN1_STRUCT, SC_ASN1_TAG_SEQUENCE | SC_ASN1_CONS, 0, NULL, NULL },
  { NULL, 0, 0, 0, NULL, NULL }
};
static const struct sc_asn1_entry c_asn1_cert[] = {
  { "x509Certificate", SC_ASN1_PKCS15_OBJECT, SC_ASN1_TAG_SEQUENCE | SC_ASN1_CONS, 0, NULL, NULL },
  { NULL, 0, 0, 0, NULL, NULL }
};

int sc_pkcs15_decode_cdf_entry(struct sc_pkcs15_card *p15card,
             struct sc_pkcs15_object *obj,
             const u8 ** buf, size_t *buflen)
{
        sc_context_t *ctx = p15card->card->ctx;
  struct sc_pkcs15_cert_info info;
  struct sc_asn1_entry  asn1_cred_ident[3], asn1_com_cert_attr[4],
        asn1_x509_cert_attr[2], asn1_type_cert_attr[2],
        asn1_cert[2], asn1_x509_cert_value_choice[3];
  struct sc_asn1_pkcs15_object cert_obj = { obj, asn1_com_cert_attr, NULL,
               asn1_type_cert_attr };
  sc_pkcs15_der_t *der = &info.value;
  u8 id_value[128];
  int id_type;
  size_t id_value_len = sizeof(id_value);
  int r;

  sc_copy_asn1_entry(c_asn1_cred_ident, asn1_cred_ident);
  sc_copy_asn1_entry(c_asn1_com_cert_attr, asn1_com_cert_attr);
  sc_copy_asn1_entry(c_asn1_x509_cert_attr, asn1_x509_cert_attr);
  sc_copy_asn1_entry(c_asn1_x509_cert_value_choice, asn1_x509_cert_value_choice);
  sc_copy_asn1_entry(c_asn1_type_cert_attr, asn1_type_cert_attr);
  sc_copy_asn1_entry(c_asn1_cert, asn1_cert);
  
  sc_format_asn1_entry(asn1_cred_ident + 0, &id_type, NULL, 0);
  sc_format_asn1_entry(asn1_cred_ident + 1, &id_value, &id_value_len, 0);
  sc_format_asn1_entry(asn1_com_cert_attr + 0, &info.id, NULL, 0);
  sc_format_asn1_entry(asn1_com_cert_attr + 1, &info.authority, NULL, 0);
  sc_format_asn1_entry(asn1_com_cert_attr + 2, asn1_cred_ident, NULL, 0);
  sc_format_asn1_entry(asn1_x509_cert_attr + 0, asn1_x509_cert_value_choice, NULL, 0);
  sc_format_asn1_entry(asn1_x509_cert_value_choice + 0, &info.path, NULL, 0);
  sc_format_asn1_entry(asn1_x509_cert_value_choice + 1, &der->value, &der->len, 0);
  sc_format_asn1_entry(asn1_type_cert_attr + 0, asn1_x509_cert_attr, NULL, 0);
  sc_format_asn1_entry(asn1_cert + 0, &cert_obj, NULL, 0);

        /* Fill in defaults */
        memset(&info, 0, sizeof(info));
  info.authority = 0;
  
  r = sc_asn1_decode(ctx, asn1_cert, *buf, *buflen, buf, buflen);
  /* In case of error, trash the cert value (direct coding) */
  if (r < 0 && der->value)
    free(der->value);
  if (r == SC_ERROR_ASN1_END_OF_CONTENTS)
    return r;
  SC_TEST_RET(ctx, r, "ASN.1 decoding failed");
  r = sc_pkcs15_make_absolute_path(&p15card->file_app->path, &info.path);
  if (r < 0)
    return r;
  obj->type = SC_PKCS15_TYPE_CERT_X509;
  obj->data = malloc(sizeof(info));
  if (obj->data == NULL)
    SC_FUNC_RETURN(ctx, 0, SC_ERROR_OUT_OF_MEMORY); 
  obj->flags |= SC_PKCS15_CO_FLAG_OBJECT_SEEN; /* certifact on demand */
  memcpy(obj->data, &info, sizeof(info));

  return 0;
}

void sc_pkcs15_free_certificate(struct sc_pkcs15_cert *cert)
{
  assert(cert != NULL);

  sc_pkcs15_erase_pubkey(&cert->key);
  free(cert->subject);
  free(cert->issuer);
  free(cert->serial);
  free(cert->data);
  free(cert->crl);
  free(cert);
}

void sc_pkcs15_free_cert_info(sc_pkcs15_cert_info_t *cert)
{
  if (!cert)
    return;
  if (cert->value.value)
    free(cert->value.value);
  free(cert);
}
