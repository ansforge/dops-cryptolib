#!/bin/bash

./signpkg.sh 5.2.1
